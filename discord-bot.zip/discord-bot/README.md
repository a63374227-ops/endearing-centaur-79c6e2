# 🤖 بوت Discord عام

بوت Discord عام بـ Node.js و Slash Commands، جاهز للنشر المجاني على Render.com ليعمل 24/7 بدون انقطاع.

## ✨ المميزات

- 🏓 أمر `/ping` - عرض زمن استجابة البوت
- 📊 أمر `/serverinfo` - معلومات السيرفر
- 👤 أمر `/userinfo` - معلومات أي مستخدم
- 🖼️ أمر `/avatar` - عرض الصورة الشخصية
- 💬 أمر `/say` - إرسال رسالة عبر البوت (يحتاج صلاحية)
- 📖 أمر `/help` - قائمة كل الأوامر
- 🎉 ترحيب تلقائي بالأعضاء الجدد
- ⚡ Slash Commands حديثة (تظهر عند كتابة `/`)
- 🛡️ معالجة أخطاء لتفادي انقطاع البوت
- 🔄 خادم Keep-Alive لمنع Render من إيقاف البوت

## 📦 المتطلبات

- Node.js 18 أو أحدث
- حساب Discord Developer
- حساب GitHub (مجاني)
- حساب Render.com (مجاني)
- حساب UptimeRobot (مجاني) - لمنع البوت من النوم

---

## 🚀 الخطوة 1: إنشاء البوت على Discord

1. اذهب إلى: https://discord.com/developers/applications
2. اضغط **"New Application"** وأعطه اسماً
3. من القائمة الجانبية اذهب إلى **"Bot"**
4. اضغط **"Reset Token"** وانسخ التوكن (لن تراه مرة أخرى!)
5. تحت **"Privileged Gateway Intents"** فعّل:
   - ✅ **Presence Intent**
   - ✅ **Server Members Intent** (مطلوب لحدث الترحيب)
   - ✅ **Message Content Intent**
6. من القائمة الجانبية اذهب إلى **"OAuth2"**
7. انسخ **"Client ID"** (يسمى أيضاً Application ID)

## 🔗 الخطوة 2: دعوة البوت إلى سيرفرك

1. من نفس صفحة OAuth2، اذهب إلى **"URL Generator"**
2. اختر:
   - **Scopes**: `bot`, `applications.commands`
   - **Bot Permissions**: `Send Messages`, `Embed Links`, `Read Message History`, `View Channels`, `Manage Messages`
3. انسخ الرابط وافتحه في المتصفح لإضافة البوت لسيرفرك

---

## 💻 الخطوة 3: إعداد المشروع محلياً (اختياري للاختبار)

```bash
# فك ضغط المشروع ثم:
cd discord-bot

# تثبيت المكتبات
npm install

# إنشاء ملف .env
cp .env.example .env

# عدّل ملف .env وضع القيم:
# DISCORD_TOKEN=توكن_البوت
# CLIENT_ID=معرف_التطبيق
# GUILD_ID=معرف_سيرفرك_للاختبار (اختياري)

# تسجيل أوامر Slash (مررة واحدة فقط)
npm run deploy

# تشغيل البوت
npm start
```

---

## 🌐 الخطوة 4: رفع المشروع إلى GitHub

```bash
# داخل مجلد discord-bot:
git init
git add .
git commit -m "Discord Bot - Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/discord-bot.git
git push -u origin main
```

> إذا لم يكن عندك حساب GitHub، أنشئ واحداً مجاناً: https://github.com

---

## ☁️ الخطوة 5: النشر على Render.com

### 5.1 إنشاء الخدمة

1. اذهب إلى: https://dashboard.render.com
2. اضغط **"New +"** > **"Web Service"**
3. اربط حساب GitHub واختر المستودع الذي رفعته
4. املأ البيانات:
   - **Name**: `discord-general-bot`
   - **Runtime**: `Node`
   - **Region**: `Oregon` (أو الأقرب لك)
   - **Branch**: `main`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: `Free`

### 5.2 إضافة متغيرات البيئة

في نفس الصفحة، انزل إلى قسم **"Environment"** واضغط **"Add Environment Variable"**:

| Key | Value |
|-----|-------|
| `DISCORD_TOKEN` | توكن البوت من Discord Developer Portal |
| `CLIENT_ID` | معرف التطبيق (Application ID) |
| `GUILD_ID` | (اختياري) معرف السيرفر لتسجيل الأوامر فوراً |

### 5.3 النشر

1. اضغط **"Create Web Service"**
2. انتظر اكتمال الـ Build (قد يأخذ 1-2 دقيقة)
3. سترى في الـ Logs: `[✓] تم تسجيل الدخول بنجاح: BotName#1234`

### 5.4 تسجيل أوامر Slash (مرة واحدة فقط)

في الـ Logs على Render، اذهب إلى **"Shell"** ونفّذ:
```bash
npm run deploy
```

> أو يمكنك تشغيل `npm run deploy` محلياً قبل الرفع إلى GitHub.

---

## ⏰ الخطوة 6: منع البوت من النوم (مهم جداً!)

Render Free Plan **ينام بعد 15 دقيقة** من عدم وجود طلبات HTTP. لذلك:

### 6.1 إنشاء Ping على UptimeRobot

1. اذهب إلى: https://uptimerobot.com وأنشئ حساب مجاني
2. اضغط **"Add New Monitor"**
3. املأ:
   - **Monitor Type**: `HTTP(s)`
   - **Friendly Name**: `Discord Bot`
   - **URL**: `https://discord-general-bot.onrender.com/health` (غيّر الـ URL حسب اسم خدمتك)
   - **Monitoring Interval**: `5 minutes`
4. اضغط **"Create Monitor"**

### 6.2 التحقق

- بعد دقائق، ادخل إلى لوحة Render وتأكد أن البوت لم يدخل في وضع Sleep
- يجب أن ترى في Logs طلبات HTTP كل 5 دقائق

---

## 📂 بنية المشروع

```
discord-bot/
├── commands/             # مجلد أوامر Slash
│   ├── ping.js
│   ├── serverinfo.js
│   ├── userinfo.js
│   ├── avatar.js
│   ├── say.js
│   └── help.js
├── events/               # مجلد أحداث Discord
│   ├── ready.js          # عند جاهزية البوت
│   ├── interactionCreate.js  # عند استلام أمر Slash
│   └── guildMemberAdd.js    # عند انضمام عضو جديد
├── index.js              # الملف الرئيسي
├── keep-alive.js         # خادم HTTP لمنع النوم
├── deploy-commands.js    # لتسجيل أوامر Slash في Discord
├── package.json
├── render.yaml           # إعدادات Render.com
├── .env.example          # مثال على متغيرات البيئة
├── .gitignore
└── README.md             # هذا الملف
```

---

## ➕ إضافة أوامر جديدة

أنشئ ملف جديد في مجلد `commands/` بالشكل التالي:

```javascript
import { SlashCommandBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('اسم_الأمر')  // بدون /
  .setDescription('وصف الأمر');

export async function execute(interaction) {
  await interaction.reply('مرحباً!');
}
```

ثم نفّذ `npm run deploy` لتسجيل الأمر في Discord.

---

## 🛠️ حل المشاكل الشائعة

| المشكلة | الحل |
|---------|-----|
| الأوامر لا تظهر | شغّل `npm run deploy` لتسجيلها |
| `DISCORD_TOKEN is undefined` | تأكد من إضافة التوكن في Environment Variables على Render |
| البوت ينام | تأكد من إعداد UptimeRobot بشكل صحيح |
| `Missing Access` | تأكد من إعطاء البوت الصلاحيات الصحيحة عند إضافته للسيرفر |
| `Privileged Intents` | فعّلها من Discord Developer Portal > Bot |
| البوت لا يرحب بالأعضاء | فعّل **Server Members Intent** وسمّ القناة `welcome` أو `ترحيب` |

---

## 📝 ملاحظات مهمة

- 🔒 **لا ترفع ملف `.env` إلى GitHub** (تم إضافته في `.gitignore`)
- ⚠️ **لا تشارك توكن البوت مع أحد** - يعطيه تحكم كامل ببوتك
- 💰 Render Free Plan: 750 ساعة شهرياً (تكفي لبوت واحد يعمل 24/7)
- 🔄 البوت قد ينام رغم كل شيء في ساعات الذروة على Render

## 📜 الترخيص

MIT License - حر في الاستخدام والتعديل.

---

**سؤال؟ تواصل مع مجتمع Discord.js**: https://discord.gg/djs
