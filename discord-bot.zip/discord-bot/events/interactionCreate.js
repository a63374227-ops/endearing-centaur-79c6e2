import { Events } from 'discord.js';

export const name = Events.InteractionCreate;

export async function execute(interaction, client) {
  // معالجة أوامر Slash
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);

  if (!command) {
    console.error(`[!] لم يتم العثور على الأمر: ${interaction.commandName}`);
    return interaction.reply({ content: '❌ هذا الأمر غير موجود!', ephemeral: true }).catch(() => {});
  }

  try {
    await command.execute(interaction);
    console.log(`[i] تم تنفيذ الأمر /${interaction.commandName} بواسطة ${interaction.user.tag}`);
  } catch (error) {
    console.error(`[!] خطأ في تنفيذ الأمر ${interaction.commandName}:`, error);

    const errorMessage = {
      content: '❌ حدث خطأ أثناء تنفيذ الأمر. حاول مرة أخرى لاحقاً.',
      ephemeral: true,
    };

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(errorMessage).catch(() => {});
    } else {
      await interaction.reply(errorMessage).catch(() => {});
    }
  }
}
