import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('serverinfo')
  .setDescription('يعرض معلومات عن السيرفر الحالي');

export async function execute(interaction) {
  const guild = interaction.guild;
  if (!guild) {
    return interaction.reply({ content: '❌ هذا الأمر يعمل فقط داخل السيرفر!', ephemeral: true });
  }

  const owner = await guild.fetchOwner();

  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle(`📊 معلومات السيرفر: ${guild.name}`)
    .setThumbnail(guild.iconURL({ size: 256 }))
    .addFields(
      { name: '🆔 معرف السيرفر', value: `\`${guild.id}\``, inline: true },
      { name: '👑 المالك', value: owner.user.tag, inline: true },
      { name: '📅 تاريخ الإنشاء', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
      { name: '👥 الأعضاء', value: `${guild.memberCount}`, inline: true },
      { name: '💬 القنوات', value: `${guild.channels.cache.size}`, inline: true },
      { name: '🎭 الأدوار', value: `${guild.roles.cache.size}`, inline: true },
      { name: '😀 الإيموجي', value: `${guild.emojis.cache.size}`, inline: true },
      { name: '🚀 مستوى التعزيز', value: `المستوى ${guild.premiumTier} (${guild.premiumSubscriptionCount} تعزيز)`, inline: true },
      { name: '🔒 مستوى التحقق', value: verificationLevel(guild.verificationLevel), inline: true },
    )
    .setFooter({ text: `طلب بواسطة ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

function verificationLevel(level) {
  const levels = ['None', 'Low', 'Medium', 'High', 'Highest'];
  return levels[level] || 'Unknown';
}
