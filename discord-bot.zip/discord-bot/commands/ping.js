import { SlashCommandBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('ping')
  .setDescription('يعرض زمن استجابة البوت (latency)');

export async function execute(interaction) {
  const sent = await interaction.reply({
    content: '⏳ جاري حساب زمن الاستجابة...',
    fetchReply: true,
  });
  const latency = sent.createdTimestamp - interaction.createdTimestamp;
  const apiLatency = Math.round(interaction.client.ws.ping);

  await interaction.editReply({
    content: `🏓 **Pong!**\n📊 زمن الاستجابة: **${latency}ms**\n🌐 زمن API: **${apiLatency}ms**`,
  });
}
