import { Events, EmbedBuilder } from 'discord.js';

export const name = Events.GuildMemberAdd;

export async function execute(member, client) {
  console.log(`[i] عضو جديد: ${member.user.tag} انضم إلى ${member.guild.name}`);

  // ابحث عن قناة اسمها "welcome" أو "ترحيب" أو أول قناة نصية
  const welcomeChannel = member.guild.channels.cache.find(
    ch => (ch.name === 'welcome' || ch.name === 'ترحيب' || ch.name === 'general')
      && ch.isTextBased()
  );

  if (!welcomeChannel) {
    console.log('[!] لم يتم العثور على قناة ترحيب. سمت القناة يجب أن يكون: welcome أو ترحيب أو general');
    return;
  }

  // التحقق من صلاحيات البوت
  if (!welcomeChannel.permissionsFor(member.guild.members.me)?.has('SendMessages')) {
    console.log('[!] لا أملك صلاحية الإرسال في قناة الترحيب');
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(0x57F287)
    .setTitle(`أهلاً وسهلاً ${member.user.username}! 🎉`)
    .setDescription(
      `مرحباً بك في **${member.guild.name}**!\n\n` +
      `أنت العضو رقم **${member.guild.memberCount}** 🎊\n\n` +
      `نتمنى لك تجربة ممتعة معنا. لا تنسى قراءة قوانين السيرفر!`
    )
    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
    .setFooter({ text: member.guild.name, iconURL: member.guild.iconURL() })
    .setTimestamp();

  welcomeChannel.send({ content: `${member}`, embeds: [embed] }).catch(console.error);
}
