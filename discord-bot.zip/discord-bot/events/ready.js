export const name = 'clientReady';
export const once = true;

export async function execute(client) {
  console.log(`[✓] تم تسجيل الدخول بنجاح: ${client.user.tag}`);
  console.log(`[i] البوت موجود في ${client.guilds.cache.size} سيرفر`);
  console.log(`[i] يخدم ${client.users.cache.size} مستخدم`);

  // تعيين نشاط البوت (status)
  client.user.setActivity({
    name: '/help | يشاهدكم 👀',
    type: 3, // Watching
  });

  client.user.setStatus('online');
  console.log('[✓] البوت جاهز للاستخدام!');
}
