import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('userinfo')
  .setDescription('يعرض معلومات عن مستخدم')
  .addUserOption(option =>
    option.setName('user')
      .setDescription('المستخدم المراد عرض معلوماته (افتراضي: أنت)')
      .setRequired(false));

export async function execute(interaction) {
  const targetUser = interaction.options.getUser('user') || interaction.user;
  const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);

  const embed = new EmbedBuilder()
    .setColor(member?.displayColor || 0x5865F2)
    .setTitle(`معلومات المستخدم: ${targetUser.tag}`)
    .setThumbnail(targetUser.displayAvatarURL({ size: 256 }))
    .addFields(
      { name: '🆔 المعرف', value: `\`${targetUser.id}\``, inline: true },
      { name: '🤖 نوع الحساب', value: targetUser.bot ? 'بوت' : 'إنسان', inline: true },
      { name: '📅 تاريخ إنشاء الحساب', value: `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:R>`, inline: true },
    );

  if (member) {
    const roles = member.roles.cache
      .filter(r => r.id !== interaction.guild.id)
      .map(r => r.toString())
      .slice(0, 20)
      .join(' ') || 'لا يوجد';

    embed.addFields(
      { name: '📥 تاريخ الانضمام للسيرفر', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
      { name: '🎨 اللون', value: member.displayHexColor || 'افتراضي', inline: true },
      { name: `🎭 الأدوار (${member.roles.cache.size - 1})`, value: roles, inline: false },
    );
  }

  embed.setFooter({ text: `طلب بواسطة ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
