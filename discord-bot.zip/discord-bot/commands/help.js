import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('help')
  .setDescription('يعرض قائمة بكل أوامر البوت المتاحة');

export async function execute(interaction) {
  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle('📖 قائمة أوامر البوت')
    .setDescription('إليك جميع الأوامر المتاحة. استخدم `/` في Discord لرؤية القائمة الكاملة.')
    .addFields(
      { name: '/ping', value: 'يعرض زمن استجابة البوت 🏓', inline: false },
      { name: '/serverinfo', value: 'يعرض معلومات السيرفر الحالي 📊', inline: false },
      { name: '/userinfo', value: 'يعرض معلومات عن مستخدم معين 👤', inline: false },
      { name: '/avatar', value: 'يعرض صورة المستخدم الشخصية 🖼️', inline: false },
      { name: '/say', value: 'يجعل البوت يرسل رسالة (يحتاج صلاحية إدارة الرسائل) 💬', inline: false },
      { name: '/help', value: 'يعرض هذه القائمة 📖', inline: false },
    )
    .setFooter({ text: 'بوت Discord عام - يعمل 24/7', iconURL: interaction.client.user.displayAvatarURL() })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
