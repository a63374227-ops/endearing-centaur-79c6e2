import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('avatar')
  .setDescription('يعرض صورة المستخدم الشخصية (avatar)')
  .addUserOption(option =>
    option.setName('user')
      .setDescription('المستخدم (افتراضي: أنت)')
      .setRequired(false));

export async function execute(interaction) {
  const targetUser = interaction.options.getUser('user') || interaction.user;

  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle(`🖼️ صورة ${targetUser.tag}`)
    .setImage(targetUser.displayAvatarURL({ size: 1024 }))
    .setFooter({ text: `طلب بواسطة ${interaction.user.tag}` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
