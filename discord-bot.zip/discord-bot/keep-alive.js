import http from 'node:http';

/**
 * خادم HTTP بسيط لمنع Render من إيقاف البوت.
 * Render Free Plan ينام بعد 15 دقيقة من الخمول، لذلك نستخدم UptimeRobot
 * لاستدعاء هذا الخادم كل 5 دقائق لإبقاء البوت مستيقظاً.
 *
 * كما أن Render يتطلب من Web Service ربط منفذ (PORT) عند الإطلاق.
 */

const PORT = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
  if (req.url === '/' || req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'ok',
      message: 'Discord Bot is running!',
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
    }));
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
});

server.listen(PORT, () => {
  console.log(`[✓] خادم Keep-Alive يعمل على المنفذ ${PORT}`);
  console.log(`[i] استخدم UptimeRobot ل ping العنوان: http://localhost:${PORT}/health`);
});

export default server;
