import { REST, Routes } from 'discord.js';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = await import(`file://${filePath}`);
  if ('data' in command && 'execute' in command) {
    commands.push(command.data.toJSON());
  }
}

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID; // اختياري - للتسجيل في سيرفر محدد (أسرع)

if (!token || !clientId) {
  console.error('[!] تأكد من تعيين DISCORD_TOKEN و CLIENT_ID في ملف .env');
  process.exit(1);
}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log(`[i] بدأ تسجيل ${commands.length} أمر Slash...`);

    // إذا كان GUILD_ID موجود، سجل الأوامر في السيرفر (فوري)
    // وإلا سجلها عالمياً (يأخذ حتى ساعة للظهور في كل السيرفرات)
    if (guildId) {
      const data = await rest.put(
        Routes.applicationGuildCommands(clientId, guildId),
        { body: commands },
      );
      console.log(`[✓] تم تسجيل ${data.length} أمر بنجاح في السيرفر!`);
    } else {
      const data = await rest.put(
        Routes.applicationCommands(clientId),
        { body: commands },
      );
      console.log(`[✓] تم تسجيل ${data.length} أمر بنجاح عالمياً!`);
      console.log('[i] ملاحظة: قد يستغرق ظهور الأوامر حتى ساعة في كل السيرفرات.');
    }
  } catch (error) {
    console.error('[!] خطأ أثناء تسجيل الأوامر:', error);
  }
})();
