import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('say')
  .setDescription('يجعل البوت يرسل رسالة (يحتاج صلاحية إدارة الرسائل)')
  .addStringOption(option =>
    option.setName('message')
      .setDescription('الرسالة المراد إرسالها')
      .setRequired(true))
  .addChannelOption(option =>
    option.setName('channel')
      .setDescription('القناة المرسل إليها (افتراضي: القناة الحالية)')
      .setRequired(false));

export async function execute(interaction) {
  // التحقق من صلاحية المستخدم
  if (!interaction.member.permissions.has('ManageMessages')) {
    return interaction.reply({ content: '❌ تحتاج صلاحية **إدارة الرسائل** لاستخدام هذا الأمر!', ephemeral: true });
  }

  const message = interaction.options.getString('message');
  const channel = interaction.options.getChannel('channel') || interaction.channel;

  // التحقق من نوع القناة
  if (!channel.isTextBased()) {
    return interaction.reply({ content: '❌ يجب اختيار قناة نصية!', ephemeral: true });
  }

  // التحقق من صلاحيات البوت في القناة
  if (!channel.permissionsFor(interaction.guild.members.me)?.has('SendMessages')) {
    return interaction.reply({ content: '❌ لا أملك صلاحية الإرسال في هذه القناة!', ephemeral: true });
  }

  await channel.send({ content: message });
  await interaction.reply({ content: `✅ تم إرسال الرسالة إلى ${channel}!`, ephemeral: true });
}
