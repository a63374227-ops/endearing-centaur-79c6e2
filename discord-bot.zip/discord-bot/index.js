import { Client, GatewayIntentBits, Collection, Partials } from 'discord.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import './keep-alive.js'; // خادم Keep-Alive لمنع Render من إيقاف البوت

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// إنشاء عميل Discord مع الـ intents المطلوبة
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,                    // للتفاعل مع السيرفرات وأوامر Slash
    GatewayIntentBits.GuildMessages,            // لقراءة رسائل السيرفر
    GatewayIntentBits.GuildMembers,             // لحدث انضمام أعضاء جدد (يتطلب تفعيل Privileged Intent)
    GatewayIntentBits.MessageContent,           // لقراءة محتوى الرسائل (يتطلب تفعيل Privileged Intent)
  ],
  partials: [Partials.Channel, Partials.GuildMember],
});

// تخزين الأوامر في Collection
client.commands = new Collection();
client.commandArray = [];

// تحميل أوامر Slash Commands من مجلد commands/
const foldersPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(foldersPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = path.join(foldersPath, file);
  const command = await import(`file://${filePath}`);
  if ('data' in command && 'execute' in command) {
    client.commands.set(command.data.name, command);
    client.commandArray.push(command.data.toJSON());
    console.log(`[+] تم تحميل الأمر: ${command.data.name}`);
  } else {
    console.log(`[!] الأمر في ${filePath} ينقصه خاصية "data" أو "execute".`);
  }
}

// تحميل الأحداث من مجلد events/
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
  const filePath = path.join(eventsPath, file);
  const event = await import(`file://${filePath}`);
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
  console.log(`[+] تم تحميل الحدث: ${event.name}`);
}

// معالجة الأخطاء لتفادي انقطاع البوت
process.on('unhandledRejection', (error) => {
  console.error('[!] وعد مرفوض غير معالج:', error);
});

process.on('uncaughtException', (error) => {
  console.error('[!] استثناء غير ملتقط:', error);
});

process.on('SIGTERM', () => {
  console.log('[i] تم استلام إشارة SIGTERM - جاري إيقاف البوت...');
  client.destroy();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('[i] تم استلام إشارة SIGINT - جاري إيقاف البوت...');
  client.destroy();
  process.exit(0);
});

// تسجيل الدخول للبوت باستخدام التوكن من متغيرات البيئة
const token = process.env.DISCORD_TOKEN;
if (!token) {
  console.error('[!] لم يتم العثور على DISCORD_TOKEN في متغيرات البيئة!');
  console.error('    تأكد من إضافة التوكن في ملف .env أو في لوحة تحكم Render.com');
  process.exit(1);
}

client.login(token);
